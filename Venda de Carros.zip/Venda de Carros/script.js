function toggleMenu() {
    const menu = document.getElementById("menu");
    menu.classList.toggle("open-menu");
}

// Fecha o menu quando o mouse sair dele
document.addEventListener("DOMContentLoaded", () => {
    const menu = document.getElementById("menu");

    menu.addEventListener("mouseleave", () => {
        menu.classList.remove("open-menu");
    });
});
